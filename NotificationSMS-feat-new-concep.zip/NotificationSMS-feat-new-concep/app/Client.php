<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Client extends Model
{
    public $timestamps = false;
    protected $table = 'client';
    protected $fillable = [
        'id',
        'sexe',
        'nom',
        'contact',
        'email',
        'reference',
        'adresse',
        'category',
        'date_naissance',
        'datetime'
    ];
}
