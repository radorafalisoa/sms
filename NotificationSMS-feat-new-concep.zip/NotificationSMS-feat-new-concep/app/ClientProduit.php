<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ClientProduit extends Model
{
    public $timestamps = false;
    protected $table = 'client_produit';
    protected $fillable = [
        'id',
        'client',
        'produit'
    ];
}
