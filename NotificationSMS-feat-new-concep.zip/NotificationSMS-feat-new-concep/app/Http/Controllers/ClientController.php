<?php

namespace App\Http\Controllers;

use App\Category;
use App\Client;
use App\Produit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ClientController extends Controller
{
    function getClients(Request $request)
    {
        return response()->json(
            DB::table('client')
                ->join('category', 'client.category', '=', 'category.id')
                ->join('type', 'client.type', '=', 'type.id')
                ->select(
                    'client.id as id',
                    'client.type as typeid',
                    'type.libelle as type',
                    'client.category as categoryID',
                    'category.libelle as category',
                    'client.reference as numero',
                    'client.raison_social as raison_social',
                    'client.forme_juridique as forme_juridique',
                    'client.secteur as secteur',
                    'client.nom as nom',
                    'client.prenom as prenom',
                    'client.sexe as sexe',
                    'client.date_naissance as naissance',
                    'client.contact as contact',
                    'client.adresse as adresse',
                    'client.email as email',
                    'client.num_card as num_card',
                    'client.data_card as data_card',
                    'client.active as active',
                    'client.datetime as datetime',
                    'client.note as note'
                )->get()
        );
    }

    function getCleientProduits(Request $request)
    {
        return response()->json(
            DB::table('client_produit')
                ->join('client', 'client_produit.client', '=', 'client.id')
                ->join('produit', 'client_produit.produit', '=', 'produit.id')
                ->join('category', 'client.category', '=', 'category.id')
                ->select('produit.id as produitID', 'client.id as clientID', 'client.nom as client', 'client.reference as numero', 'client.date_naissance as naissance', 'client.contact as contact', 'client.sexe as sexe', 'client.adresse as adresse', 'produit.libelle as produit', 'category.id as categoryID', 'category.libelle as category', 'client.email as email')
                ->get()
        );
    }

    function getClientByProduit(Request $request)
    {
        return response()->json(
            DB::table('client_produit')
                ->join('client', 'client_produit.client', '=', 'client.id')
                ->join('produit', 'client_produit.produit', '=', 'produit.id')
                ->join('category', 'client.category', '=', 'category.id')
                ->select('produit.id as produitID', 'client.id as clientID', 'client.nom as client', 'client.contact as contact', 'client.sexe as sexe', 'client.adresse as adresse', 'produit.libelle as produit', 'category.id as categoryID', 'category.libelle as category')
                ->where('client_produit.produit', '=', $request->produit)
                ->get()
        );
    }

    function getClientByIds(Request $request)
    {
        return response()->json(
            DB::table('client')
                ->join('category', 'client.category', '=', 'category.id')
                ->select('client.id as id', 'client.nom as nom', 'client.email as email', 'client.contact as contact', 'client.adresse as adresse', 'category.libelle as category', 'client.datetime as datetime', 'client.sexe as sexe')
                ->whereIn('client.id', $request->client)
                ->get()
        );
    }

    function getClientType()
    {
        return response()->json(
            DB::table('type')->select('libelle', 'id')->get()
        );
    }

    function getCategories(Request $request)
    {
        return response()->json(
            DB::table('category')->select('libelle', 'id')->get()
        );
    }

    function countClient()
    {
        return DB::table('client')->count();
    }

    function storeClient(Request $request)
    {
        $client = new Client();
        if (intval($request->type) === 2) {
            $client->nom = $request->nom;
            $client->prenom = $request->prenom;
            $client->sexe = $request->sexe;
        } else {
            $client->raison_social = $request->raison_social;
            $client->forme_juridique = $request->forme_juridique;
            $client->secteur = $request->secteur;
        }
        $client->type = $request->type;
        $client->contact = $request->contact;
        $client->adresse = $request->adresse;
        $client->email = $request->email;
        $client->category = $request->category;
        $client->num_card = $request->numero_carte;
        $client->data_card = $request->data_carte;
        $client->date_naissance = $request->naissance;
        $client->note = $request->note;
        $client->reference = '00000';
        $client->active = true;
        $client->save();
        return response()->json("client added");
    }

    function deleteClient(Request $request)
    {
        Client::where('id', '=', $request->client)->delete();
        return response()->json('client deleted');
    }

    function findClientById(Request $request)
    {
        return response()->json(Client::where('id', '=', $request->client)->first());
    }

    function updateClient(Request $request)
    {
        return Client::where('id', $request->id)->update([
            'sexe' => $request->sexe,
            'nom' => $request->nom,
            'contact' => $request->contact,
            'adresse' => $request->adress,
            'email' => $request->email,
            'category' => $request->category,
            'date_naissance' => $request->naissance
        ]);
    }

    function saveProduit(Request $request)
    {
        $produit = new Produit();
        $produit->libelle = $request->produit;
        return $produit->save();
    }

    function saveCategory(Request $request)
    {
        $category = new Category();
        $category->libelle = $request->category;
        return $category->save();
    }
}
