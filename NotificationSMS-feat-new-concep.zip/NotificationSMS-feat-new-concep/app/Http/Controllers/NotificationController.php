<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class NotificationController extends Controller
{
    function getNotifications(Request $request)
    {
        return response()->json(DB::table('notification')
            ->join('client', 'notification.client', '=', 'client.id')
            ->select('client.id as clientid', 'client.nom as client', 'client.contact', 'client.produit as produit', 'notification.envoye as status', 'mail', 'notification.date_envoi as envoie', 'notification.datetime as datenotif')
            ->get());
    }

    function getNotificationsWait(Request $request)
    {
        return response()->json(DB::table('notification')
            ->join('client', 'notification.client', '=', 'client.id')
            ->select('client.id as clientid', 'client.nom as client', 'client.contact', 'client.produit as produit', 'notification.envoye as status', 'mail', 'notification.date_envoi as envoie', 'notification.datetime as datenotif')
            ->where('notification.envoye', '=', 1)
            ->get());
    }

    function getAllProduits(Request $request)
    {
        return response()->json(DB::table('produit')->select('id', 'libelle')->get());
    }

    function filtreClientProduit(Request $request)
    {
        $data = DB::table('client_produit')
            ->join('client', 'client_produit.client', '=', 'client.id')
            ->join('produit', 'client_produit.produit', '=', 'produit.id')
            ->join('category', 'client.category', '=', 'category.id')
            ->select('produit.id as produitID', 'client.id as clientID', 'client.nom as client', 'client.reference as numero', 'client.date_naissance as naissance', 'client.contact as contact', 'client.sexe as sexe', 'client.adresse as adresse', 'produit.libelle as produit', 'category.id as categoryID', 'category.libelle as category', 'client.email as email');
        if ($request->category !== null) $data->where('client.category', '=', $request->category);
        if ($request->produit !== null) $data->where('client_produit.produit', '=', $request->produit);
        if ($request->sexe !== null) $data->where('client.sexe', '=', $request->sexe);
        return response()->json($data->get());


    }
}
