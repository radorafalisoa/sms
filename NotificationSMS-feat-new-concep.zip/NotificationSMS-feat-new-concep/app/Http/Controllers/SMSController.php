<?php

namespace App\Http\Controllers;

use App\Client;
use Illuminate\Http\Request;
use Mediumart\Orange\SMS\Http\SMSClient;
use Mediumart\Orange\SMS\SMS;

class SMSController extends Controller
{
    public function sendSMS($phone, $message)
    {
        $client = SMSClient::getInstance(env('ORANGE_SMS_API_TOKEN'));
        $sms = new SMS($client);
        $sms->message($message)
            ->from(env('ORANGE_SMS_API_ADRESS'))
            ->to('+261' . substr($phone, 1))
            ->send();
    }

    public function sendBulkSMStoClient(Request $request)
    {
        $sms = new \App\Sms();
        $sms->contenu = $request->contenu;
        $sms->save();
        $idSMSClient = array();
        foreach ($request->client as $clt) {
            $Client = Client::where('id', '=', $clt)->first();//
            $Sms_client = new \App\SMSClient();
            $Sms_client->sms = $sms->id;
            $Sms_client->client = $clt;
            $Sms_client->save();
            array_push($idSMSClient, $Sms_client->id);
        }

        foreach ($idSMSClient as $id) {
            $clientSMS = \App\SMSClient::where('id', '=', $id)->first();
            $client = Client::where('id', '=', $clientSMS->client)->first();
            $this->sendSMS($client->contact, $request->contenu);

        }
        return response()->json("data sms send");
    }
}
