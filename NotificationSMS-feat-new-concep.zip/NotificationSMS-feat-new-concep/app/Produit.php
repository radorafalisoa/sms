<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Produit extends Model
{
    public $timestamps = false;
    protected $table = 'produit';
    protected $fillable = [
        'id',
        'libelle'
    ];
}
