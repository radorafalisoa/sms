<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SMSClient extends Model
{
    public $timestamps = false;
    protected $table = 'sms_client';
    protected $fillable = [
        'id',
        'sms',
        'client',
    ];
}
