<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Client;
use Faker\Generator as Faker;
use Illuminate\Support\Str;

$factory->define(Client::class, function (Faker $faker) {
    return [
        'sexe' => Str::random('1'),
        'nom' => $faker->name,
        'email' => $faker->safeEmail,
        'reference' => Str::random('10'),
        'contact' => $faker->phoneNumber,
        'adresse' => $faker->address,
        'category' => $faker->numberBetween(1, 4),
        'datetime' => $faker->dateTime,
        'date_naissance' => $faker->dateTimeBetween(['-40 ans', '-10 ans'])
    ];
});
