<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\ClientProduit;
use Faker\Generator as Faker;

$factory->define(ClientProduit::class, function (Faker $faker) {
    return [
        'client' => $faker->numberBetween(1, 110),
        'produit' => $faker->numberBetween(1, 17)
    ];
});
