<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Produit;
use Faker\Generator as Faker;
use Illuminate\Support\Str;

$factory->define(Produit::class, function (Faker $faker) {
    return [
        'libelle' => Str::random(20)
    ];
});
