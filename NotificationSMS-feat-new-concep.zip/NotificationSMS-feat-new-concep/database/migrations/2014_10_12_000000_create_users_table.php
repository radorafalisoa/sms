<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
//        Schema::create('users', function (Blueprint $table) {
//            $table->id();
//            $table->string('name');
//            $table->string('email')->unique();
//            $table->timestamp('email_verified_at')->nullable();
//            $table->string('password');
//            $table->rememberToken();
//            $table->timestamps();
//        });

//        Schema::create('client', function (Blueprint $table) {
//            $table->id();
//            $table->string('nom');
//            $table->string('adresse');
//            $table->string('contact');
//            $table->string('produit');
//            $table->string('mail');
//            $table->timestamp('datetime')->default(DB::raw('CURRENT_TIMESTAMP'))->index();
//            $table->engine = 'InnoDB';
//            $table->charset = 'utf8';
//            $table->collation = 'utf8_general_ci';
//        });
//
//
//        Schema::create('notification', function (Blueprint $table) {
//            $table->id();
//            $table->unsignedBigInteger('client');
//            $table->boolean('envoye')->default(true);
//            $table->timestamp('date_envoi')->nullable();
//            $table->timestamp('datetime')->default(DB::raw('CURRENT_TIMESTAMP'))->index();
//            $table->foreign('client')->references('id')->on('client');
//            $table->engine = 'InnoDB';
//            $table->charset = 'utf8';
//            $table->collation = 'utf8_general_ci';
//        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('client');
        Schema::dropIfExists('notification');
    }
}
