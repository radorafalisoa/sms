<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateNotificationTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('category', function (Blueprint $table) {
            $table->increments('id');
            $table->string('libelle');
            $table->engine = 'InnoDB';
            $table->charset = 'utf8';
            $table->collation = 'utf8_general_ci';
        });

        Schema::create('type', function (Blueprint $table) {
            $table->increments('id');
            $table->string('libelle');
            $table->engine = 'InnoDB';
            $table->charset = 'utf8';
            $table->collation = 'utf8_general_ci';
        });

        Schema::create('client', function (Blueprint $table) {
            $table->id();
            $table->string('reference');
            $table->string('raison_social')->nullable();
            $table->string('forme_juridique')->nullable();
            $table->string('secteur')->nullable();
            $table->string('nom')->nullable();
            $table->string('prenom')->nullable();
            $table->char('sexe')->nullable();
            $table->timestamp('date_naissance')->nullable();
            $table->string('contact')->nullable();
            $table->string('adresse')->nullable();
            $table->string('email')->nullable();
            $table->unsignedInteger('category');
            $table->unsignedInteger('type');
            $table->string('num_card')->nullable();
            $table->string('data_card')->nullable();
            $table->boolean('active');
            $table->text('note');

            $table->timestamp('datetime')->default(DB::raw('CURRENT_TIMESTAMP'))->index();
            $table->foreign('category')->references('id')->on('category');
            $table->foreign('type')->references('id')->on('type');
            $table->engine = 'InnoDB';
            $table->charset = 'utf8';
            $table->collation = 'utf8_general_ci';
        });

        Schema::create('produit', function (Blueprint $table) {
            $table->id('id');
            $table->string('libelle');
            $table->string('prix');
            $table->engine = 'InnoDB';
            $table->charset = 'utf8';
            $table->collation = 'utf8_general_ci';
        });

        Schema::create('sms', function (Blueprint $table) {
            $table->id();
            $table->text('contenu');
            $table->timestamp('datetime')->default(DB::raw('CURRENT_TIMESTAMP'))->index();
            $table->engine = 'InnoDB';
            $table->charset = 'utf8';
            $table->collation = 'utf8_general_ci';
        });

        Schema::create('sms_client', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('sms');
            $table->unsignedBigInteger('client');
            $table->foreign('sms')->references('id')->on('sms');
            $table->foreign('client')->references('id')->on('client');
            $table->timestamp('datetime')->default(DB::raw('CURRENT_TIMESTAMP'))->index();
            $table->timestamp('date_send')->nullable();
            $table->text('contenue');
            $table->engine = 'InnoDB';
            $table->charset = 'utf8';
            $table->collation = 'utf8_general_ci';
        });

        Schema::create('achat', function (Blueprint $table) {
            $table->id('id');
            $table->unsignedBigInteger('client');
            $table->foreign('client')->references('id')->on('client');
            $table->timestamp('datetime')->default(DB::raw('CURRENT_TIMESTAMP'))->index();
            $table->string('status');
            $table->engine = 'InnoDB';
            $table->charset = 'utf8';
            $table->collation = 'utf8_general_ci';
        });

        Schema::create('detail_achat', function (Blueprint $table) {
            $table->id('id');
            $table->unsignedBigInteger('achat');
            $table->unsignedBigInteger('produit');
            $table->float('quantite');
            $table->timestamp('datetime')->default(DB::raw('CURRENT_TIMESTAMP'))->index();
            $table->engine = 'InnoDB';
            $table->charset = 'utf8';
            $table->collation = 'utf8_general_ci';
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('category');
        Schema::dropIfExists('client');
        Schema::dropIfExists('type');
        Schema::dropIfExists('sms');
        Schema::dropIfExists('produit');
        Schema::dropIfExists('sms_client');
        Schema::dropIfExists('achat');
        Schema::dropIfExists('detail_achat');
    }
}
