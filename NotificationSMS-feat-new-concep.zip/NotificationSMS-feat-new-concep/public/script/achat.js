window.onload = function () {
    console.log('achat');
};

function getAllAchat() {
    var datatable = $('#table-client').dataTable();
    $.ajax({
        url: '/allClient',
        type: 'POST',
        success: function (data) {
            console.log(data);
            var row = '';
            $.each(data, function (i, item) {

            });
            datatable.fnDestroy();
            $('#table-achat tbody').html(row);
            $('#table-achat').DataTable({
                'aoColumnDefs': [{
                    'aTargets': [0]
                }],
                'oLanguage': {
                    'sLengthMenu': 'Show _MENU_ Rows',
                    'sSearch': '',
                    'oPaginate': {
                        'sPrevious': '',
                        'sNext': ''
                    }
                },
                'aaSorting': [[1, 'asc']],
                'aLengthMenu': [[5, 10, 15, 20, -1], [5, 10, 15, 20, 'All'] // change per page values here
                ],
                // set the initial value
                'iDisplayLength': 20,
            });

        },
        error: function (err) {
            console.log(err);
        }
    });
}

function storeAchat() {

}

function getClients() {
    $.ajax({
        url: '/allClient',
        type: 'POST',
        success: function (data) {
            console.log(data);
            var options = '';
            $.each(data, function (i, item) {
                if ()
                options += '<option value=' + item.id + '>' + item.libelle + '</option>';
            });
            $('select[name="select-client"]').html(options);

        },
        error: function (err) {
            console.log(err);
        }
    });
}
