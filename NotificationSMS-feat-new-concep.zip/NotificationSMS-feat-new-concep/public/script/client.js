$(document).ready(function () {
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf_token"]').attr('content')
        }
    });
    $('#data_naissance').datepicker({
        format: 'yyyy-mm-dd'
    });
    gettypeClient();
    getClients();
    getCategories();
});

function getClients() {
    var datatable = $('#table-client').dataTable();
    $.ajax({
        url: '/allClient',
        type: 'POST',
        success: function (data) {
            console.log(data);
            var row = '';
            $.each(data, function (i, item) {
                row += `<tr><td>${item.numero}</td>`;
                if (parseInt(item.typeid) === 2) {
                    row += `<td id="client-${item.id}">${item.nom} ${item.prenom} (${item.sexe})</td>`;
                } else {
                    row += `<td id="client-${item.id}">${item.raison_social} ${item.forme_juridique} </td>`;
                }
                row += `<td> ${item.type} </td>` +
                    `<td> ${item.adresse} </td>` +
                    `<td> ${item.contact} </td>` +
                    `<td> ${item.category} </td>` +
                    `<td> ${item.email} </td>` +
                    `<td> ${moment(item.naissance).format('DD-MM-YYYY')} </td>`;
                if (item.active === 1) {
                    row += `<td>` +
                        `<button class="btn btn-xs btn-outline-danger tooltips" onclick="deleteClient(${item.id})"><i class="fa fa-times fa fa-white"></i></button>` + ' ' +
                        `<button class="btn btn-xs btn-outline-success tooltips" onclick="editClient(${item.id})"><i class="fa fa-edit fa fa-white"></i></button>` +
                        `</td>`;
                } else {
                    row += `<td><button class="btn btn-xs btn-outline-info tooltips"><i class="fa fa-check fa fa-white"></i></button></td>`;
                }

                row += `</tr>`;
            });
            datatable.fnDestroy();
            $('#table-client tbody').html(row);
            $('#table-client').DataTable({
                'aoColumnDefs': [{
                    'aTargets': [0]
                }],
                'oLanguage': {
                    'sLengthMenu': 'Show _MENU_ Rows',
                    'sSearch': '',
                    'oPaginate': {
                        'sPrevious': '',
                        'sNext': ''
                    }
                },
                'aaSorting': [[1, 'asc']],
                'aLengthMenu': [[5, 10, 15, 20, -1], [5, 10, 15, 20, 'All'] // change per page values here
                ],
                // set the initial value
                'iDisplayLength': 20,
            });

        },
        error: function (err) {
            console.log(err);
        }
    });
}

function getCategories() {
    $.ajax({
        url: '/allCategories',
        type: 'POST',
        success: function (data) {
            var options = '';
            $.each(data, function (i, item) {
                options += '<option value=' + item.id + '>' + item.libelle + '</option>';
            });
            $('select[name="select-category"]').html(options);
            $('select[name="select-category-filtre"]').html(options);
        },
        error: function (err) {
            console.log(err);
        }
    });
}

function gettypeClient() {
    $.ajax({
        url: '/allType',
        type: 'POST',
        success: function (data) {
            var options = '';
            $.each(data, function (i, item) {
                options += '<option value=' + item.id + '>' + item.libelle + '</option>';
            });
            $('select[name="select-type"]').html(options);
        },
        error: function (err) {
            console.log(err);
        }
    });
}

function setAppearDiv() {
    if (parseInt($('select[name="select-type"]').val()) === 2) {
        $('#societe-attributes').hide();
        $('#particulier-attribute').removeAttr('hidden');
        $('#particulier-attribute').show();
    } else {
        $('#societe-attributes').show();
        $('#particulier-attribute').hide();

    }
}

function storeClient() {
    var formData = new FormData();
    if (parseInt($('select[name="select-type"]').val()) === 2) { // particulier
        formData.append('nom', $('input[name="nom"]').val());
        formData.append('prenom', $('input[name="prenom"]').val());
        formData.append('sexe', $('input[name="sexe"]:checked').val());
    } else {  // société ou autres
        formData.append('raison_social', $('input[name="raison_social"]').val());
        formData.append('forme_juridique', $('input[name="forme_juridique"]').val());
        formData.append('secteur', $('input[name="secteur"]').val());
    }

    formData.append('type', $('select[name="select-type"]').val());
    formData.append('category', $('select[name="select-category"]').val());
    formData.append('email', $('input[name="email"]').val());
    formData.append('contact', $('input[name="contact"]').val());
    formData.append('adresse', $('input[name="adress"]').val());
    formData.append('numero_carte', $('input[name="numero_carte"]').val());
    formData.append('data_carte', $('input[name="data_carte"]').val());
    formData.append('naissance', $('input[name="data_naissance"]').val());
    formData.append('note', $('textarea[name="note"]').val());

    $.ajax({
        url: '/saveClient',
        type: 'POST',
        contentType: false,
        processData: false,
        dataType: 'JSON',
        data: formData,
        success: function () {
            getClients();
            $("#modal-client").modal('hide');
        },
        error: function (err) {
            console.log(err);
        }
    });

}

function deleteClient(id) {
    $('#modal-delete-client').modal('show');
    $('#client-name').html($('#client-' + id).text());
    $('#confirm-delete-client').click(function () {
        $.ajax({
            url: '/deleteClient',
            type: 'POST',
            data: {'client': id},
            success: function () {
                getClients();
                $("#modal-delete-client").modal('hide');
            },
            error: function (err) {
                console.log(err);
            }
        });
    });
}

function editClient(id) {
    console.log(id);
    $.ajax({
        url: '/findClientById',
        type: 'POST',
        data: {'client': id},
        success: function (data) {
            console.log(data);
            if (data !== null) {
                $('#num-client').html(data.reference);
                $('input[name="name"]').val(data.nom);
                $('input[name="contact"]').val(data.contact);
                $('input[name="email"]').val(data.email);
                $('input[name="adress"]').val(data.adresse);
                $('input[name="data_naissance"]').val(moment(data.date_naissance).format('YYYY-MM-DD'));
                $(`input[name="sexe"][value="${data.sexe}"]`).prop('checked', true);
                $('select[name="select-category"]').val(data.category);
                $("#modal-client").modal('show');
                $('#id_client').val(data.id);
                $('#valid-store').attr("hidden", true);
                $('#valid-update').removeAttr("hidden");
            }
        },
        error: function (err) {
            console.log(err);
        }
    });
}

function renewButton() {
    $('#valid-update').attr("hidden", true);
    $('#valid-store').removeAttr("hidden");
}

function saveClient() {
    var formData = new FormData();
    formData.append('id', $('input[name="id_client"]').val());
    formData.append('nom', $('input[name="name"]').val());
    formData.append('sexe', $('input[name="sexe"]:checked').val());
    formData.append('email', $('input[name="email"]').val());
    formData.append('contact', $('input[name="contact"]').val());
    formData.append('adress', $('input[name="adress"]').val());
    formData.append('naissance', $('input[name="data_naissance"]').val());
    formData.append('category', $('select[name="select-category"]').val());
    $.ajax({
        url: '/storeClient',
        type: 'POST',
        contentType: false,
        processData: false,
        dataType: 'JSON',
        data: formData,
        success: function () {
            console.log('done');
            getClients();
            $("#modal-client").modal('hide');
        },
        error: function (err) {
            console.log(err);
        }
    });
}

