$(document).ready(function () {
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf_token"]').attr('content')
        }
    });
    getNotifications();
});

function getNotifications() {
    $.ajax({
        url: '/notification',
        type: 'POST',
        success: function (data) {
            console.log(data);
            var row = '';
            $.each(data, function (i, item) {
                row += `<tr>` +
                    `<td>${item.client}</td>` +
                    `<td>${item.contact}</td>` +
                    `<td>${item.produit}</td>` +
                    `<td>${(item.status === 0) ? 'Envoyé' : 'En cours'}</td>` +
                    `<td>${(item.envoie !== null) ? item.envoie : '-'}</td>` +
                    `<td>${item.datenotif}</td>` +
                    `<td>` +
                    `<button class="btn btn-xs btn-success tooltips"><i class="fa fa-share fa fa-white"></i></button>` +
                    `</td>` +
                    `</tr>`;
            });
            $('#table-notification tbody').html(row);
            $('#table-notification').DataTable({
                'aoColumnDefs': [{
                    'aTargets': [0]
                }],
                'oLanguage': {
                    'sLengthMenu': 'Show _MENU_ Rows',
                    'sSearch': '',
                    'oPaginate': {
                        'sPrevious': '',
                        'sNext': ''
                    }
                },
                'aaSorting': [[1, 'asc']],
                'aLengthMenu': [[5, 10, 15, 20, -1], [5, 10, 15, 20, 'All'] // change per page values here
                ],
                // set the initial value
                'iDisplayLength': 10,
            });
        },
        error: function (err) {
            console.log(err);
        }
    });
}
