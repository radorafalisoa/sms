$(document).ready(function () {
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf_token"]').attr('content')
        }
    });
    toastr.success('Hé, <b>ça marche !</b>', 'Test');

    getClientProduit();
    getProduits();
    getCategories();
});

$('#selectAll').click(function (e) {
    var table = $(e.target).closest('table');
    $('td input:checkbox', table).prop('checked', this.checked);
});

function getClientProduit() {
    $.ajax({
        url: '/clientProduits',
        type: 'POST',
        success: function (data) {
            console.log(data);
            var row = '';
            $.each(data, function (i, item) {
                row += `<tr id="${item.clientID}">` +
                    `<td><div class="checkbox-custom checkbox-success"><input type="checkbox" id="client-${item.clientID}" name="getchemist"><label for="checkboxExample3"></label></div></td>'` +
                    `<td>${item.numero}</td>` +
                    `<td>${item.client}</td>` +
                    `<td>${item.sexe}</td>` +
                    `<td>${item.contact}</td>` +
                    `<td>${item.adresse}</td>` +
                    `<td>${item.email}</td>` +
                    `<td>${item.produit}</td>` +
                    `<td>${moment(item.naissance).format('DD-MM-YYYY')}</td>` +
                    `<td>${item.category}</td>` +
                    `</tr>`;
            });
            $('#table-all-produit-client tbody').html(row);
        },
        error: function (err) {
            console.log(err);
        }
    });
}

function getProduits() {
    $.ajax({
        url: '/allProduits',
        type: 'POST',
        success: function (data) {
            console.log(data);
            var options = '';
            $.each(data, function (i, item) {
                options += '<option value=' + item.id + '>' + item.libelle + '</option>';
            });
            options += '<option value="tous">Tous</option>';
            $('select[name="select-produits"]').html(options);
        },
        error: function (err) {
            console.log(err);
        }
    });
}

function getClientByProduit() {
    var produit = $('#produit-select').val();
    $.ajax({
        url: '/clientByProduit',
        type: 'POST',
        data: {
            'produit': produit
        },
        success: function (data) {
            console.log(data);
            var row = '';
            $.each(data, function (i, item) {
                row += `<tr id="${item.clientID}">` +
                    `<td><div class="checkbox-custom checkbox-success"><input type="checkbox" id="client-${item.clientID}" name="getchemist"><label for="checkboxExample3"></label></div></td>'` +
                    `<td>${item.clientID}</td>` +
                    `<td>${item.client}</td>` +
                    `<td>${item.contact}</td>` +
                    `<td>${item.adresse}</td>` +
                    `<td>${item.produit}</td>` +
                    `<td>${item.category}</td>` +
                    `</tr>`;
            });
            $('#table-all-produit-client tbody').html(row);
        },
        error: function (err) {
            console.log(err);
        }
    });
}

function filterClient() {
    var formdata = new FormData();
    if ($('select[name="select-category-filtre"]').val() !== 'tous') formdata.append('category', $('select[name="select-category-filtre"]').val());
    if ($('select[name="select-produits"]').val() !== 'tous') formdata.append('produit', $('select[name="select-produits"]').val());
    if ($('input[name="sexe"]:checked').val() !== 'tous') formdata.append('sexe', $('input[name="sexe"]:checked').val());
    $.ajax({
        url: '/filtreClientProduit',
        type: 'POST',
        contentType: false,
        processData: false,
        dataType: 'JSON',
        data: formdata,
        success: function (data) {
            console.log(data);
            if (data !== null) {
                var row = '';
                $.each(data, function (i, item) {
                    row += `<tr id="${item.clientID}">` +
                        `<td><div class="checkbox-custom checkbox-success"><input type="checkbox" id="client-${item.clientID}" name="getchemist"><label for="checkboxExample3"></label></div></td>'` +
                        `<td>${item.numero}</td>` +
                        `<td>${item.client}</td>` +
                        `<td>${item.contact}</td>` +
                        `<td>${item.adresse}</td>` +
                        `<td>${item.email}</td>` +
                        `<td>${item.produit}</td>` +
                        `<td>${moment(item.naissance).format('YYYY-MM-DD')}</td>` +
                        `<td>${item.category}</td>` +
                        `</tr>`;
                });
                $('#table-all-produit-client tbody').html(row);
            }
        },
        error: function (err) {
            console.log(err);
        }
    });
}

function sendSMS() {
    var arrId = [];
    $(':checkbox:checked').each(function () {
        var id = $(this).closest('tr').attr('id');
        arrId.push(id);
    });
    var tab = [];
    $.each(arrId, function (i, item) {
        if (item === 'selectall-check' || item === undefined) return;
        tab.push(parseInt(item));
    });

    var clients = [];
    (new Set(tab)).forEach(st => {
        clients.push(st);
    });
    if (tab.length > 0) {
        $.ajax({
            url: '/getClientById',
            type: 'POST',
            data: {
                'client': clients
            },
            success: function (data) {
                var row = '';
                $.each(data, function (i, item) {
                    row += `<tr>` +
                        `<td>${item.nom}</td>` +
                        `<td>${item.contact}</td>` +
                        `<td>${item.category}</td>` +
                        `<td>${item.email}</td>` +
                        `</tr>`;
                });
                $('#table-client-modal tbody').html(row);
                $('#sms-modal').modal('show');
            },
            error: function (err) {
                console.log(err);
            }
        });
    }

    $('#btn-valid-sms-send').click(function () {
        $.ajax({
            url: '/sendSMSClient',
            type: 'POST',
            data: {
                'client': clients,
                'contenu': $('#content-sms').val()
            },
            success: function (data) {
                toastr.success('Notification sms envoyé à tous les clients', 'Notification SMS');
                $('#sms-modal').modal('hide');
            },
            error: function (err) {
                console.log(err);
            }
        });
    });

}

function getCategories() {
    $.ajax({
        url: '/allCategories',
        type: 'POST',
        success: function (data) {
            var options = '';
            $.each(data, function (i, item) {
                options += '<option value=' + item.id + '>' + item.libelle + '</option>';
            });
            options += '<option value="tous">Tous</option>';
            $('select[name="select-category-filtre"]').html(options);
        },
        error: function (err) {
            console.log(err);
        }
    });
}
