$(document).ready(function () {
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf_token"]').attr('content')
        }
    });
    getProduits();
    getClientProduit();
    getCategory();
    getClients();
});

function getClients() {
    $.ajax({
        url: '/allClient',
        type: 'POST',
        success: function (data) {
            console.log(data);
            if (data !== null) {
                var options = '';
                $.each(data, function (i, item) {
                    options += '<option value=' + item.id + '>' + item.nom + '</option>';
                });
                $('select[name="select-client"]').html(options);
            }
        },
        error: function (err) {
            console.log(err);
        }
    });
}

function getProduits() {
    var datatable = $('#table-produit').dataTable();
    $.ajax({
        url: '/allProduits',
        type: 'POST',
        success: function (data) {
            console.log(data);
            var row = '';
            var options = '';
            $.each(data, function (i, item) {
                options += '<option value=' + item.id + '>' + item.libelle + '</option>';
                row += `<tr>` +
                    `<td>${item.libelle}</td>` +
                    `<td>` +
                    `<button class="btn btn-xs btn-outline-success tooltips"><i class="fa fa-edit fa fa-white"></i></button>` +
                    `</td>` +
                    `</tr>`;
            });
            $('select[name="select-produit"]').html(options);
            datatable.fnDestroy();
            $('#table-produit tbody').html(row);
            $('#table-produit').DataTable({
                'aoColumnDefs': [{
                    'aTargets': [0]
                }],
                'oLanguage': {
                    'sLengthMenu': 'Show _MENU_ Rows',
                    'sSearch': '',
                    'oPaginate': {
                        'sPrevious': '',
                        'sNext': ''
                    }
                },
                'aaSorting': [[1, 'asc']],
                'aLengthMenu': [[5, 10, 15, 20, -1], [5, 10, 15, 20, 'All'] // change per page values here
                ],
                // set the initial value
                'iDisplayLength': 10,
            });

        },
        error: function (err) {
            console.log(err);
        }
    });
}

function getClientProduit() {
    $.ajax({
        url: '/clientProduits',
        type: 'POST',
        success: function (data) {
            console.log(data);
            var row = '';
            $.each(data, function (i, item) {
                row += `<tr>` +
                    `<td>${item.client}</td>` +
                    `<td>${item.sexe}</td>` +
                    `<td>${item.contact}</td>` +
                    `<td>${item.adresse}</td>` +
                    `<td>${item.produit}</td>` +
                    `<td>` +
                    `<button class="btn btn-xs btn-danger tooltips"><i class="fa fa-times fa fa-white"></i></button>` + ' ' +
                    `<button class="btn btn-xs btn-success tooltips"><i class="fa fa-edit fa fa-white"></i></button>` +
                    `</td>` +
                    `</tr>`;
            });
            $('#client_produit tbody').html(row);
            $('#client_produit').DataTable({
                'aoColumnDefs': [{
                    'aTargets': [0]
                }],
                'oLanguage': {
                    'sLengthMenu': 'Show _MENU_ Rows',
                    'sSearch': '',
                    'oPaginate': {
                        'sPrevious': '',
                        'sNext': ''
                    }
                },
                'aaSorting': [[1, 'asc']],
                'aLengthMenu': [[5, 10, 15, 20, -1], [5, 10, 15, 20, 'All'] // change per page values here
                ],
                // set the initial value
                'iDisplayLength': 10,
            });

        },
        error: function (err) {
            console.log(err);
        }
    });
}

function getCategory() {
    var datatable = $('#table-category').dataTable();
    $.ajax({
        url: '/allCategories',
        type: 'POST',
        success: function (data) {
            console.log(data);
            var row = '';

            $.each(data, function (i, item) {
                row += `<tr>` +
                    `<td>${item.libelle}</td>` +
                    `<td>` +
                    `<button class="btn btn-xs btn-outline-success tooltips"><i class="fa fa-edit fa fa-white"></i></button>` +
                    `</td>` +
                    `</tr>`;
            });
            datatable.fnDestroy();
            $('#table-category tbody').html(row);
            $('#table-category').DataTable({
                'aoColumnDefs': [{
                    'aTargets': [0]
                }],
                'oLanguage': {
                    'sLengthMenu': 'Show _MENU_ Rows',
                    'sSearch': '',
                    'oPaginate': {
                        'sPrevious': '',
                        'sNext': ''
                    }
                },
                'aaSorting': [[1, 'asc']],
                'aLengthMenu': [[5, 10, 15, 20, -1], [5, 10, 15, 20, 'All'] // change per page values here
                ],
                // set the initial value
                'iDisplayLength': 10,
            });

        },
        error: function (err) {
            console.log(err);
        }
    });
}

function addProduit() {
    $.ajax({
        url: '/addProduit',
        type: 'POST',
        data: {
            'produit': $('#libelle-produit').val()
        },
        success: function () {
            console.log('done');
            getProduits();
            $("#modal-produit").modal('hide');
        },
        error: function (err) {
            console.log(err);
        }
    });
}

function addCategory() {
    $.ajax({
        url: '/addCategory',
        type: 'POST',
        data: {
            'category': $('#libelle-category').val()
        },
        success: function () {
            console.log('done');
            getCategory();
            $("#modal-category").modal('hide');
        },
        error: function (err) {
            console.log(err);
        }
    });
}
