@extends('adminlte::page')

@section('title', 'Dashboard')

@section('content_header')
    <h1>Achat</h1>
    <meta name="csrf_token" content="{{ csrf_token() }}">
    <link href="<?= url('/') ?>/plugins/datetimepicker/css/daterangepicker.css" rel="stylesheet"/>
    <link href="<?= url('/') ?>/plugins/bootstrap-datepicker/css/bootstrap-datepicker.min.css" rel="stylesheet"/>
@stop

@section('content')
    <div class="row">
        <div class="col-md-6">
            <table class="table table-hover" id="table-achat">
                <thead>
                <tr>
                    <th>#</th>
                    <th>Client</th>
                    <th>Date Achat</th>
                    <th>Montant Total</th>
                    <th>
                        <button class="btn btn-outline-success btn-sm" data-toggle="modal" data-target="#modal-achat"><i
                                class="fa fa-plus"></i></button>
                    </th>
                </tr>
                </thead>
                <tbody>

                </tbody>
            </table>
        </div>
        <div class="col-md-6" id="detal-achat-div">
            <table class="table table-hover" id="table-detail-achat">
                <thead>
                <tr>
                    <th>#</th>
                    <th>Produit</th>
                    <th>PU</th>
                    <th>Montant</th>
                    <th>
                        <button class="btn btn-outline-success btn-xs" data-toggle="modal" data-target="#modal-detail-achat"><i
                                class="fa fa-plus"></i></button>
                    </th>
                </tr>
                </thead>
                <tbody>

                </tbody>
            </table>
        </div>
    </div>

    <div class="modal fade" id="modal-delete-client" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
         aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Confirmation de Suppression</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    Voullez-vous vraiment supprimer le client <span class="text-danger" id="client-name"></span> ??
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-sm btn-danger" id="confirm-delete-client">Supprimer</button>
                    <button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="modal-achat" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle"
         aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle">Achat <span class="text-success"
                                                                                      id="num-client"></span></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form name="form-client">
                        <input type="hidden" name="id_achat" id="id_achat">
                        <div class="form-group">
                            <label for="select-type">Client</label>
                            <select class="form-control input-sm" name="select-client" id="select-client">

                            </select>
                        </div>
                        <div class="form-group">
                            <label for="data_naissance">Date Achat</label>
                            <input type="text" class="form-control" id="date_achat" name="date_achat">
                        </div>

                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" id="valid-store" onclick="storeAchat()">Enregistrer
                    </button>
                    <button type="button" class="btn btn-primary" id="valid-update" hidden onclick="saveClient()">
                        Valider
                    </button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
@stop

@section('css')
    <link rel="stylesheet" href="/css/admin_custom.css">
@stop

@section('js')
    <script> console.log('Hi!'); </script>
    <script src="<?= url('/') ?>/script/jquery.validate.min.js"></script>
    <script src="<?= url('/') ?>/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script>
    <script src="<?= url('/') ?>/plugins/datetimepicker/js/daterangepicker.js"></script>
    <script src="<?= url('/') ?>/script/moment.js"></script>
    <script src="<?= url('/') ?>/script/achat.js"></script>
@stop
