@extends('adminlte::page')

@section('title', 'Dashboard')

@section('content_header')
    <h1>Clients</h1>
    <meta name="csrf_token" content="{{ csrf_token() }}">
    <link href="<?= url('/') ?>/plugins/datetimepicker/css/daterangepicker.css" rel="stylesheet"/>
    <link href="<?= url('/') ?>/plugins/bootstrap-datepicker/css/bootstrap-datepicker.min.css" rel="stylesheet"/>
@stop

@section('content')
    <table class="table table-hover" id="table-client">
        <thead>
        <tr>
            <th>Numero</th>
            <th>Nom/Raison Social</th>
            <th>Type</th>
            <th>Adresse</th>
            <th>Contact</th>
            <th>Category</th>
            <th>Mail</th>
            <th>Apparition</th>
            <th>
                <button class="btn btn-outline-success btn-sm" data-toggle="modal" data-target="#modal-client"
                        onclick="renewButton()"><i
                        class="fa fa-plus"></i></button>
            </th>
        </tr>
        </thead>
        <tbody>

        </tbody>
    </table>

    <div class="modal fade" id="modal-delete-client" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
         aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Confirmation de Suppression</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    Voullez-vous vraiment supprimer le client <span class="text-danger" id="client-name"></span> ??
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-sm btn-danger" id="confirm-delete-client">Supprimer</button>
                    <button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="modal-client" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle"
         aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle">Client : <span class="text-success"
                                                                                      id="num-client"></span></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form name="form-client">
                        <input type="hidden" name="id_client" id="id_client">
                        <div class="form-group">
                            <label for="select-type">Type</label>
                            <select class="form-control input-sm" name="select-type" onchange="setAppearDiv()"
                                    id="select-type">

                            </select>
                        </div>

                        <div id="societe-attributes">
                            <div class="form-group">
                                <label for="name">Raison Social </label>
                                <input type="text" class="form-control" id="raison_social" name="raison_social">
                            </div>
                            <div class="form-group">
                                <label for="name">Forme Juridique </label>
                                <input type="text" class="form-control" id="forme_juridique" name="forme_juridique">
                            </div>
                            <div class="form-group">
                                <label for="name">Secteur </label>
                                <input type="text" class="form-control" id="secteur" name="secteur">
                            </div>
                        </div>
                        <div id="particulier-attribute" hidden>
                            <div class="form-group">
                                <label for="name">Nom </label>
                                <input type="text" class="form-control" id="nom" name="nom">
                            </div>
                            <div class="form-group">
                                <label for="name">Prénom(s) </label>
                                <input type="text" class="form-control" id="prenom" name="prenom">
                            </div>
                            <div class="form-group">
                                <div class="custom-control custom-radio custom-control-inline">
                                    <input type="radio" id="sexe" name="sexe" class="custom-control-input" value="M">
                                    <label class="custom-control-label" for="sexe">Masculin</label>
                                </div>
                                <div class="custom-control custom-radio custom-control-inline">
                                    <input type="radio" id="sexe2" name="sexe" class="custom-control-input" value="F">
                                    <label class="custom-control-label" for="sexe2">Feminin</label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="select-category">Categorie</label>
                            <select class="form-control" name="select-category" id="select-category">

                            </select>
                        </div>
                        <div class="form-group">
                            <label for="formGroupExampleInput2">Email</label>
                            <input type="email" class="form-control" id="email" name="email"
                                   placeholder="ex: example@example.com">
                        </div>
                        <div class="form-group">
                            <label for="contact">Contact</label>
                            <input type="text" class="form-control" id="contact" name="contact"
                                   placeholder="ex: +261 32 XX XXX XX">
                        </div>
                        <div class="form-group">
                            <label for="adress">Adresse</label>
                            <input type="text" class="form-control" id="adress" name="adress"
                                   placeholder="ex: 67 Ha">
                        </div>

                        <div class="form-group">
                            <label for="contact">Numero de carte</label>
                            <input type="text" class="form-control" id="numero_carte" name="numero_carte"
                                   placeholder="ex: 032XXXXXXX">
                        </div>
                        <div class="form-group">
                            <label for="adress">Data Card</label>
                            <input type="text" class="form-control" id="data_carte" name="data_carte"
                                   placeholder="ex: 67 Ha">
                        </div>

                        <div class="form-group">
                            <label for="data_naissance">Naissance</label>
                            <input type="text" class="form-control" id="data_naissance" name="data_naissance">
                        </div>

                        <div class="form-group">
                            <label for="adress">Note</label>
                            <textarea class="form-control" rows="2" id="note" name="note"></textarea>
                        </div>

                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" id="valid-store" onclick="storeClient()">Enregistrer
                    </button>
                    <button type="button" class="btn btn-primary" id="valid-update" hidden onclick="saveClient()">
                        Valider
                    </button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
@stop

@section('css')
    <link rel="stylesheet" href="/css/admin_custom.css">
@stop

@section('js')
    <script> console.log('Hi!'); </script>
    <script src="<?= url('/') ?>/script/jquery.validate.min.js"></script>
    <script src="<?= url('/') ?>/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script>
    <script src="<?= url('/') ?>/plugins/datetimepicker/js/daterangepicker.js"></script>
    <script src="<?= url('/') ?>/script/moment.js"></script>
    <script src="<?= url('/') ?>/script/client.js"></script>
@stop
