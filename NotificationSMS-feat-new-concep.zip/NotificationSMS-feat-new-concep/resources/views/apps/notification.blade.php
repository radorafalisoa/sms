@extends('adminlte::page')

@section('title', 'Dashboard')

@section('content_header')
    <h1>Notification en attente</h1>
    <meta name="csrf_token" content="{{ csrf_token() }}">
    <link href="<?= url('/') ?>/css/toastr.min.css" rel="stylesheet"/>
@stop

@section('content')
    <!-- Button trigger modal -->
    <div class="row">
        <div class="col-md-4 offset-md-4">
            <div class="input-group mb-3">
                <div class="input-group-prepend">
                    <label class="input-group-text" for="inputGroupSelect01">Categories</label>
                </div>
                <select class="custom-select" id="select-category-filtre"
                        name="select-category-filtre">

                </select>
            </div>
            <div class="input-group mb-3">
                <div class="input-group-prepend">
                    <label class="input-group-text" for="inputGroupSelect01">Produits</label>
                </div>
                <select class="custom-select" id="produit-select"
                        name="select-produits">

                </select>
            </div>
            <div class="form-group">
                <div class="custom-control custom-radio custom-control-inline">
                    <input type="radio" id="sexe" name="sexe" class="custom-control-input" value="M">
                    <label class="custom-control-label" for="sexe">Masculin</label>
                </div>
                <div class="custom-control custom-radio custom-control-inline">
                    <input type="radio" id="sexe2" name="sexe" class="custom-control-input" value="F">
                    <label class="custom-control-label" for="sexe2">Feminin</label>
                </div>
                <div class="custom-control custom-radio custom-control-inline">
                    <input type="radio" id="sexe3" name="sexe" class="custom-control-input" value="tous">
                    <label class="custom-control-label" for="sexe3">Tous</label>
                </div>
            </div>
            <button type="button" class="btn btn-sm btn-block btn-outline-primary btn-sm" onclick="filterClient()">
                Filtrer
            </button>
            <button type="button" class="btn btn-sm btn-block btn-outline-success btn-sm" onclick="sendSMS()">Send SMS
            </button>
        </div>
    </div><br>
    <div class="row">
        <div class="col-md-12">
            <table class="table table-hover" id="table-all-produit-client">
                <thead>
                <tr id="selectall-check">
                    <th class="center">
                        <div class="checkbox-table">
                            <label>
                                <input type="checkbox" class="flat-grey selectall" id="selectAll">
                            </label>
                        </div>
                    </th>
                    <th>Numero</th>
                    <th>Nom</th>
                    <th>Sexe</th>
                    <th>Contact</th>
                    <th>Adresse</th>
                    <th>mail</th>
                    <th>Produit</th>
                    <th>Naissance</th>
                    <th>Category</th>
                </tr>
                </thead>
                <tbody>

                </tbody>
            </table>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade bd-example-modal-lg" id="sms-modal" tabindex="-1" aria-labelledby="exampleModalLabel"
         aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Nouvelle Notification</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12">
                            <table class="table table-hover" id="table-client-modal" data-height="100px;">
                                <thead>
                                <tr>
                                    <th>Nom</th>
                                    <th>Contact</th>
                                    <th>Category</th>
                                    <th>Email</th>
                                </tr>
                                </thead>
                                <tbody>

                                </tbody>
                            </table>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="content-sms" class="text-center">Contenue du message</label>
                                <textarea class="form-control" id="content-sms" rows="3"></textarea>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-sm btn-primary" id="btn-valid-sms-send">Valider</button>
                    <button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal">Annuler</button>
                </div>
            </div>
        </div>
    </div>
@stop

@section('css')
    <link rel="stylesheet" href="/css/admin_custom.css">
@stop

@section('js')
    <script src="<?= url('/') ?>/script/moment.js"></script>
    <script src="<?= url('/') ?>/script/toastr.min.js"></script>
    <script src="<?= url('/') ?>/script/notificationwait.js"></script>
@stop
