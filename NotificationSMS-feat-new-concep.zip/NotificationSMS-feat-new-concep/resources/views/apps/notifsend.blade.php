@extends('adminlte::page')

@section('title', 'Dashboard')

@section('content_header')
    <h1>Notification envoyé</h1>
    <meta name="csrf_token" content="{{ csrf_token() }}">
@stop

@section('content')
    <table class="table table-hover" id="table-notification">
        <thead>
        <tr>
            <th>Nom</th>
            <th>Contact</th>
            <th>Produit</th>
            <th>Status</th>
            <th>Date Nofitication</th>
            <th>Date envoi</th>
            <th></th>
        </tr>
        </thead>
        <tbody>

        </tbody>
    </table>
@stop

@section('css')
    <link rel="stylesheet" href="/css/admin_custom.css">
@stop

@section('js')
    <script> console.log('Hi!'); </script>
    <script src="<?= url('/') ?>/script/notification.js"></script>
@stop
