<?php

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('clients', function () {
    return view('apps.clients');
});

Route::get('produits', function () {
    return view('apps.produits');
});

Route::get('notif-all', function () {
    return view('apps.notification');
});

Route::get('notif-wait', function () {
    return view('apps.notifsend');
});

Route::get('achat', function () {
    return view('apps.achat');
});

Route::post('allClient', 'ClientController@getClients');
Route::post('allType', 'ClientController@getClientType');
Route::post('notification', 'NotificationController@getNotifications');
Route::post('notification-wait', 'NotificationController@getNotificationsWait');
Route::post('allProduits', 'NotificationController@getAllProduits');
Route::post('clientProduits', 'ClientController@getCleientProduits');
Route::post('clientByProduit', 'ClientController@getClientByProduit');
Route::post('addProduit', 'ClientController@saveProduit');
Route::post('addCategory', 'ClientController@saveCategory');

Route::get('test', function () {
    $smsController = new \App\Http\Controllers\SMSController();
    $smsController->sendSMS('0320297148', 'test letsy eeeee');
});

Route::post('sendSMSClient', 'SMSController@sendBulkSMStoClient');
Route::post('getClientById', 'ClientController@getClientByIds');
Route::post('allCategories', 'ClientController@getCategories');
Route::post('saveClient', 'ClientController@storeClient');
Route::post('deleteClient', 'ClientController@deleteClient');
Route::post('findClientById', 'ClientController@findClientById');
Route::post('storeClient', 'ClientController@updateClient');
Route::post('filtreClientProduit', 'NotificationController@filtreClientProduit');
